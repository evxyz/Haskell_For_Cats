{-# LANGUAGE NoMonomorphismRestriction #-}
module Nov14 
-- :set prompt ghci> 
-- :set guifont=Consolas 16
-- :set gfn=Consolas\ 16
-- :set expandtab 
-- :set ts=3  
-- Show sum [x] = x for any number
-- Give another result for (double(double 2)) 
-- 7 `div` 2 -- note `div` rounds down to nearest proper fraction 
Danielle S. 
   case commons 
   
   other peoples programs = puzzles 
      legacy 
     read the error message. 
         "no really" 
     Read the line number.
      Google the error
      Street light effect 
         looking where the light is 
            theories you can disprove the fastest. 
               will get you to the ones that matter
      can you reproduce the bug.
         or can you watch someone reproduce the problem 
      video the problem 
         cause the user might be doing something that nobody else does. 

      partial patterns can be informative 
         
      break things down into smaller peices 
         dont try and under 

      miller (7 plus or minus 2)
      
      commenting out parts to reduce the problem space 
         fixing typos can even help you focus 
            write tests to doc existing behavior
               where there was some. 
      what are the facts 
            and the 

     put in a flag to see how far your getting 
         nil might be "" or [] 
   
      State of the universe 

      Clean out the environment 
         sketch it 
            list it 
               what's the story or it. 
                  you're mind is your thinking attic 
      What are your assumptions 
         an informal 
      
      If you can explain it to your rubber duck 

      Trust no one 
         
      debugger 
         Linus Torvalds 
            doesn't replace understanding 


      print statemenstrates
         underrated 

      experiment is the core of science 
         
      what has changed since the problem   

      Git tricks 
        its a magical time machine 
            diff branch 
               show diff 
manual 
       git bisect start 
       git bisect good SHA 
       git bisect bad HEAD 
auto 
      git bisect start HEAD HEAD 

Debugger 
   
   make friends with pry 
   Its also a great open source project 
   
   binding 

  This shouldn't make a difference but try it anyway.
 

  $ bundle open gem_name 
   only rarely is it the compiler 
      mostly it's you. 
   
    
