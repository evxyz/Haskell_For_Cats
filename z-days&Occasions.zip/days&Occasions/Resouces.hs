http://www.meetup.com/Haskell_For_Cats/



Erik Meijer's video 
https://channel9.msdn.com/Series/C9-Lectures-Erik-Meijer-Functional-Programming-Fundamentals/Lecture-Series-Erik-Meijer-Functional-Programming-Fundamentals-Chapter-1 


static typing
http://www.logicmatters.net/resources/pdfs/Galois.pdf
http://www.dpmms.cam.ac.uk/~martin/Research/Publications/2007/hp07.pdf
http://www.tac.mta.ca/tac/reprints/articles/5/tr5abs.html


